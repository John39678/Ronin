
class CodeAnalyzer {
  constructor() {
    this.rules = [
      { id: 'missing-semicolon', pattern: /[^;}\s]\s*\n/, message: 'Missing semicolon', fixable: true },
      { id: 'unused-var', pattern: /var\s+\w+\s*=.*?;/, message: 'Consider using let/const instead of var', fixable: true },
      { id: 'console-log', pattern: /console\.log\(/, message: 'Remove console.log in production', fixable: true },
      { id: 'double-equals', pattern: /==(?!=)/, message: 'Use === instead of ==', fixable: true },
      { id: 'eval-usage', pattern: /eval\s*\(/, message: 'Avoid eval() - security risk', fixable: false }
    ];
    this.appliedFixes = [];
  }

  analyze(code, filename = 'unknown') {
    const issues = [];
    const lines = code.split('\n');
    
    lines.forEach((line, index) => {
      this.rules.forEach(rule => {
        if (rule.pattern.test(line)) {
          issues.push({
            rule: rule.id,
            message: rule.message,
            line: index + 1,
            code: line.trim(),
            severity: this.getSeverity(rule.id)
          });
        }
      });
    });

    return {
      filename,
      totalLines: lines.length,
      issues,
      score: this.calculateScore(issues, lines.length),
      suggestions: this.generateSuggestions(issues)
    };
  }

  getSeverity(ruleId) {
    const severityMap = {
      'eval-usage': 'error',
      'double-equals': 'warning',
      'missing-semicolon': 'warning',
      'unused-var': 'info',
      'console-log': 'info'
    };
    return severityMap[ruleId] || 'info';
  }

  calculateScore(issues, totalLines) {
    if (totalLines === 0) return 100;
    
    const errorCount = issues.filter(i => i.severity === 'error').length;
    const warningCount = issues.filter(i => i.severity === 'warning').length;
    const infoCount = issues.filter(i => i.severity === 'info').length;
    
    const penalty = (errorCount * 10) + (warningCount * 5) + (infoCount * 2);
    const score = Math.max(0, 100 - penalty);
    
    return score;
  }

  generateSuggestions(issues) {
    const suggestions = [];
    
    if (issues.some(i => i.rule === 'unused-var')) {
      suggestions.push('Use modern ES6+ syntax: replace var with let/const');
    }
    
    if (issues.some(i => i.rule === 'console-log')) {
      suggestions.push('Remove debug console.log statements before production');
    }
    
    if (issues.some(i => i.rule === 'double-equals')) {
      suggestions.push('Use strict equality (===) to avoid type coercion issues');
    }
    
    return suggestions;
  }

  autoFix(code, issues = []) {
    this.appliedFixes = [];
    let fixedCode = code;
    
    // If no specific issues provided, analyze the code first
    if (issues.length === 0) {
      const analysis = this.analyze(code);
      issues = analysis.issues;
    }
    
    // Apply fixes in order of importance
    issues.forEach(issue => {
      const rule = this.rules.find(r => r.id === issue.rule);
      if (rule && rule.fixable) {
        fixedCode = this.applyFix(fixedCode, issue);
      }
    });
    
    return fixedCode;
  }
  
  applyFix(code, issue) {
    const lines = code.split('\n');
    let fixedLines = [...lines];
    
    switch (issue.rule) {
      case 'unused-var':
        // Replace var with const (or let if reassigned)
        fixedLines[issue.line - 1] = fixedLines[issue.line - 1].replace(/\bvar\b/, 'const');
        this.appliedFixes.push(`Line ${issue.line}: Replaced 'var' with 'const'`);
        break;
        
      case 'double-equals':
        // Replace == with ===
        fixedLines[issue.line - 1] = fixedLines[issue.line - 1].replace(/==(?!=)/g, '===');
        this.appliedFixes.push(`Line ${issue.line}: Replaced '==' with '==='`);
        break;
        
      case 'console-log':
        // Comment out console.log
        fixedLines[issue.line - 1] = fixedLines[issue.line - 1].replace(/console\.log\(/g, '// console.log(');
        this.appliedFixes.push(`Line ${issue.line}: Commented out console.log`);
        break;
        
      case 'missing-semicolon':
        // Add semicolon at end of line
        const line = fixedLines[issue.line - 1].trim();
        if (!line.endsWith(';') && !line.endsWith('{') && !line.endsWith('}')) {
          fixedLines[issue.line - 1] = fixedLines[issue.line - 1] + ';';
          this.appliedFixes.push(`Line ${issue.line}: Added missing semicolon`);
        }
        break;
    }
    
    return fixedLines.join('\n');
  }
  
  getAppliedFixes() {
    return this.appliedFixes;
  }

  formatReport(analysis) {
    let report = `📊 **Code Analysis Report for ${analysis.filename}**\n\n`;
    report += `📈 **Quality Score:** ${analysis.score}/100\n`;
    report += `📝 **Lines of Code:** ${analysis.totalLines}\n`;
    report += `🔍 **Issues Found:** ${analysis.issues.length}\n\n`;

    if (analysis.issues.length > 0) {
      report += `**Issues:**\n`;
      analysis.issues.forEach(issue => {
        const emoji = issue.severity === 'error' ? '❌' : issue.severity === 'warning' ? '⚠️' : 'ℹ️';
        const fixableIcon = this.rules.find(r => r.id === issue.rule)?.fixable ? ' 🔧' : '';
        report += `${emoji} Line ${issue.line}: ${issue.message}${fixableIcon}\n`;
        report += `   \`${issue.code}\`\n\n`;
      });
    }

    if (analysis.suggestions.length > 0) {
      report += `**Suggestions:**\n`;
      analysis.suggestions.forEach(suggestion => {
        report += `💡 ${suggestion}\n`;
      });
    }

    return report;
  }
}

// Export as ES module
export default CodeAnalyzer;
