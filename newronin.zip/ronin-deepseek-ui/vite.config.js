import { defineConfig } from 'vite';

export default defineConfig({
  server: {
    host: '0.0.0.0',  // Makes the server available over the network
    port: 5000,       // Sets the development server's port 
    // hmr: false,    // Optional: Set to false to disable hot module reloading
  },
  // plugins: [],      // Add any plugins needed for your project
});