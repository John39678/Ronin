
// Example: Modern JavaScript Component
class ModernMenu {
  constructor(container) {
    this.container = container;
    this.init();
  }

  init() {
    this.render();
    this.attachEvents();
  }

  render() {
    this.container.innerHTML = `
      <nav class="modern-menu">
        <div class="menu-brand">
          <h1>🚀 My App</h1>
        </div>
        <ul class="menu-items">
          <li><a href="#home">Home</a></li>
          <li><a href="#about">About</a></li>
          <li><a href="#services">Services</a></li>
          <li><a href="#contact">Contact</a></li>
        </ul>
        <button class="menu-toggle">☰</button>
      </nav>
    `;
  }

  attachEvents() {
    const toggle = this.container.querySelector('.menu-toggle');
    const menu = this.container.querySelector('.menu-items');
    
    toggle.addEventListener('click', () => {
      menu.classList.toggle('active');
    });
  }
}

// Usage
document.addEventListener('DOMContentLoaded', () => {
  const menuContainer = document.getElementById('menu-container');
  new ModernMenu(menuContainer);
});
