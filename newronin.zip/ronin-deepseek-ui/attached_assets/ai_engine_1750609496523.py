# ai_engine.py
from openai import OpenAI
import ast
import astor
from typing import Dict, List

class AIAnalysisEngine:
    def __init__(self):
        self.client = OpenAI(api_key="your-api-key")
        self.personality_traits = {
            "professional": "You are a highly skilled coding assistant.",
            "friendly": "You are a helpful and friendly coding companion.",
            "humorous": "You provide coding help with a touch of humor."
        }
        self.current_personality = "professional"
        
    def analyze_code(self, code: str, context: Dict = None) -> Dict:
        """Analyze code for errors and suggest improvements"""
        prompt = self._build_analysis_prompt(code, context)
        response = self._query_ai(prompt)
        return self._parse_analysis_response(response)
    
    def suggest_fixes(self, code: str, issues: List) -> str:
        """Generate fixed version of code"""
        prompt = self._build_fix_prompt(code, issues)
        response = self._query_ai(prompt)
        return self._parse_fix_response(response)
    
    def explain_code(self, code: str) -> str:
        """Generate human-readable explanation of code"""
        prompt = f"Explain this code in detail:\n\n{code}\n\nExplanation:"
        return self._query_ai(prompt)
    
    def set_personality(self, personality: str):
        """Set the personality style of responses"""
        if personality in self.personality_traits:
            self.current_personality = personality
    
    def _build_analysis_prompt(self, code: str, context: Dict) -> str:
        base_prompt = f"""
        {self.personality_traits[self.current_personality]}
        
        Analyze the following code for errors, potential bugs, security issues, 
        and performance improvements. Provide detailed suggestions for fixes.
        
        Code:
        {code}
        
        Context: {context or 'No additional context provided'}
        
        Provide your analysis in this JSON format:
        {{
            "errors": [],
            "warnings": [],
            "performance_issues": [],
            "security_concerns": [],
            "style_violations": [],
            "suggested_fixes": [],
            "overall_quality_score": 0-100
        }}
        """
        return base_prompt
    
    def _query_ai(self, prompt: str) -> str:
        response = self.client.chat.completions.create(
            model="gpt-4",
            messages=[{"role": "user", "content": prompt}],
            temperature=0.7,
            max_tokens=2000
        )
        return response.choices[0].message.content
    
    def _parse_analysis_response(self, response: str) -> Dict:
        try:
            return json.loads(response)
        except json.JSONDecodeError:
            # Fallback parsing if JSON is malformed
            return {
                "errors": ["Failed to parse AI response"],
                "response_text": response
            }