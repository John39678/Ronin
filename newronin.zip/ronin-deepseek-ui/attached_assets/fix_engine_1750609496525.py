# fix_engine.py
import ast
import astor
from typing import List, Dict

class FixEngine:
    def __init__(self):
        self.approved_fixes = {}
        self.auto_apply = False
    
    def apply_fixes(self, original_code: str, fixes: List[Dict]) -> str:
        """Apply suggested fixes to code"""
        if not fixes:
            return original_code
            
        if self.auto_apply:
            return self._apply_all_fixes(original_code, fixes)
        else:
            return self._apply_approved_fixes(original_code, fixes)
    
    def approve_fix(self, fix_id: str):
        """Mark a specific fix as approved"""
        self.approved_fixes[fix_id] = True
    
    def set_auto_apply(self, enabled: bool):
        """Set whether fixes should be applied automatically"""
        self.auto_apply = enabled
    
    def _apply_all_fixes(self, code: str, fixes: List[Dict]) -> str:
        """Apply all suggested fixes without approval"""
        try:
            tree = ast.parse(code)
            
            # Process each fix
            for fix in fixes:
                if fix['type'] == 'variable_rename':
                    tree = self._rename_variable(tree, fix['old_name'], fix['new_name'])
                elif fix['type'] == 'function_optimization':
                    tree = self._optimize_function(tree, fix['function_name'], fix['optimization'])
                # Add more fix types as needed
                
            return astor.to_source(tree)
        except Exception as e:
            print(f"Error applying fixes: {e}")
            return code
    
    def _apply_approved_fixes(self, code: str, fixes: List[Dict]) -> str:
        """Apply only approved fixes"""
        approved = [f for f in fixes if self.approved_fixes.get(f['id'], False)]
        return self._apply_all_fixes(code, approved)
    
    def _rename_variable(self, tree, old_name, new_name):
        """AST transformation for variable renaming"""
        for node in ast.walk(tree):
            if isinstance(node, ast.Name) and node.id == old_name:
                node.id = new_name
        return tree
    
    def _optimize_function(self, tree, function_name, optimization):
        """AST transformation for function optimization"""
        # Implementation would depend on the specific optimization
        return tree