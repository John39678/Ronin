// AvatarComponent.jsx
import { useRef, useEffect } from 'react';
import * as THREE from 'three';
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls';

const AvatarComponent = ({ isThinking, isSpeaking, emotion }) => {
  const mountRef = useRef(null);
  const mixerRef = useRef(null);
  
  useEffect(() => {
    // Scene setup
    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
    const renderer = new THREE.WebGLRenderer({ alpha: true, antialias: true });
    renderer.setSize(mountRef.current.clientWidth, mountRef.current.clientHeight);
    mountRef.current.appendChild(renderer.domElement);
    
    // Lighting
    const ambientLight = new THREE.AmbientLight(0x404040);
    scene.add(ambientLight);
    const directionalLight = new THREE.DirectionalLight(0xffffff, 1);
    directionalLight.position.set(1, 1, 1);
    scene.add(directionalLight);
    
    // Holographic material
    const hologramMaterial = new THREE.MeshPhongMaterial({
      color: 0x00ffff,
      transparent: true,
      opacity: 0.8,
      emissive: 0x00ffff,
      emissiveIntensity: 0.5,
      wireframe: true,
      shininess: 100
    });
    
    // Load avatar model
    const loader = new GLTFLoader();
    loader.load('/models/ai_avatar.glb', (gltf) => {
      const avatar = gltf.scene;
      avatar.traverse((child) => {
        if (child.isMesh) {
          child.material = hologramMaterial;
        }
      });
      
      // Animation mixer
      mixerRef.current = new THREE.AnimationMixer(avatar);
      if (gltf.animations.length > 0) {
        const action = mixerRef.current.clipAction(gltf.animations[0]);
        action.play();
      }
      
      scene.add(avatar);
    });
    
    // Animation loop
    const clock = new THREE.Clock();
    const animate = () => {
      requestAnimationFrame(animate);
      
      // Update animations
      if (mixerRef.current) {
        mixerRef.current.update(clock.getDelta());
      }
      
      // Color changes based on state
      if (isThinking) {
        hologramMaterial.color.setHSL(Math.sin(clock.getElapsedTime() * 0.5) * 0.5 + 0.5, 1, 0.7);
      } else if (isSpeaking) {
        hologramMaterial.emissiveIntensity = Math.sin(clock.getElapsedTime() * 5) * 0.25 + 0.75;
      }
      
      renderer.render(scene, camera);
    };
    
    animate();
    
    return () => {
      mountRef.current.removeChild(renderer.domElement);
    };
  }, [isThinking, isSpeaking, emotion]);
  
  return <div ref={mountRef} className="avatar-container" />;
};