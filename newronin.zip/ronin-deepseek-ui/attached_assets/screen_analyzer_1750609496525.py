# screen_analyzer.py
import cv2
import pytesseract
import numpy as np
from PIL import ImageGrab
import difflib

class ScreenAnalyzer:
    def __init__(self):
        self.previous_text = ""
        self.observed_windows = []
        
    def capture_screen(self, region=None):
        """Capture screen or specific region"""
        if region:
            return ImageGrab.grab(bbox=region)
        return ImageGrab.grab()
    
    def extract_text(self, image):
        """Extract text from image using OCR"""
        # Convert to OpenCV format
        open_cv_image = np.array(image)
        open_cv_image = open_cv_image[:, :, ::-1].copy()  # Convert RGB to BGR
        
        # Preprocess for better OCR
        gray = cv2.cvtColor(open_cv_image, cv2.COLOR_BGR2GRAY)
        _, threshold = cv2.threshold(gray, 150, 255, cv2.THRESH_BINARY)
        
        # Use Tesseract OCR
        text = pytesseract.image_to_string(threshold)
        return text.strip()
    
    def detect_changes(self, new_text):
        """Detect meaningful changes in text content"""
        if not self.previous_text:
            self.previous_text = new_text
            return []
            
        diff = difflib.ndiff(self.previous_text.splitlines(), new_text.splitlines())
        changes = [line for line in diff if line.startswith('+ ') or line.startswith('- ')]
        self.previous_text = new_text
        return changes
    
    def monitor_window(self, window_title, callback):
        """Monitor a specific window for changes"""
        self.observed_windows.append({
            'title': window_title,
            'callback': callback,
            'last_state': None
        })
    
    def check_windows(self):
        """Check all observed windows for changes"""
        for window in self.observed_windows:
            # Implementation would use platform-specific APIs to get window content
            current_content = self.get_window_content(window['title'])
            if current_content != window['last_state']:
                window['callback'](current_content)
                window['last_state'] = current_content