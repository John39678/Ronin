import sys
import os
from flask import Flask, request, jsonify
from flask_cors import CORS

# Add the 'attached_assets' directory to the Python path
sys.path.append(os.path.join(os.path.dirname(__file__), 'attached_assets'))

# Now you can import the modules using their corrected filenames (without the .py extension)
from ai_engine_1750609496523 import AIAnalysisEngine
from fix_engine_1750609496525 import FixEngine

app = Flask(__name__)
CORS(app) # Enable CORS for all routes

# Initialize your AI engines
ai_engine = AIAnalysisEngine()
fix_engine = FixEngine()

@app.route('/analyze_code', methods=['POST'])
def analyze_code():
    data = request.json
    code = data.get('code')
    context = data.get('context')
    if not code:
        return jsonify({'error': 'No code provided'}), 400
    
    result = ai_engine.analyze_code(code, context)
    return jsonify(result)

@app.route('/suggest_fixes', methods=['POST'])
def suggest_fixes():
    data = request.json
    code = data.get('code')
    issues = data.get('issues')
    if not code or not issues:
        return jsonify({'error': 'Code or issues not provided'}), 400
    
    result = fix_engine.suggest_fixes(code, issues) # Assuming FixEngine has this method
    return jsonify({'fixed_code': result})

@app.route('/explain_code', methods=['POST'])
def explain_code():
    data = request.json
    code = data.get('code')
    if not code:
        return jsonify({'error': 'Code not provided'}), 400
    
    result = ai_engine.explain_code(code)
    return jsonify({'explanation': result})

@app.route('/set_personality', methods=['POST'])
def set_personality():
    data = request.json
    personality = data.get('personality')
    if not personality:
        return jsonify({'error': 'Personality not provided'}), 400
    
    ai_engine.set_personality(personality)
    return jsonify({'status': 'Personality set to ' + personality})

if __name__ == '__main__':
    app.run(port=5001, debug=True)