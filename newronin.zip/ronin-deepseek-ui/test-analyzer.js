
import CodeAnalyzer from './code-analyzer.js';

console.log('🧪 TESTING CODE ANALYZER STEP BY STEP\n');

const analyzer = new CodeAnalyzer();

// Test 1: Basic instantiation
console.log('✅ Test 1: CodeAnalyzer created successfully');

// Test 2: Simple analysis
const testCode = `var x = 5
console.log(x)
if (x == 5) {
  alert("found")
}`;

console.log('🔍 Test 2: Analyzing test code...');
try {
  const analysis = analyzer.analyze(testCode, 'test.js');
  console.log('✅ Analysis completed');
  console.log('📊 Score:', analysis.score);
  console.log('🔍 Issues found:', analysis.issues.length);
  console.log('💡 Suggestions:', analysis.suggestions.length);
  
  // Test 3: Report formatting
  console.log('\n🔍 Test 3: Formatting report...');
  const report = analyzer.formatReport(analysis);
  console.log('✅ Report formatted successfully');
  console.log('📝 Report length:', report.length, 'characters');
  
  // Test 4: Auto-fix
  console.log('\n🔍 Test 4: Testing auto-fix...');
  const fixedCode = analyzer.autoFix(testCode);
  console.log('✅ Auto-fix completed');
  console.log('🔧 Applied fixes:', analyzer.getAppliedFixes().length);
  console.log('📄 Original code length:', testCode.length);
  console.log('📄 Fixed code length:', fixedCode.length);
  
  console.log('\n🎯 ALL TESTS PASSED - CodeAnalyzer is working correctly!');
  
} catch (error) {
  console.error('❌ TEST FAILED:', error.message);
  console.error('Stack:', error.stack);
}
